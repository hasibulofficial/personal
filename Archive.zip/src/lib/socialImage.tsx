import { ImageResponse } from 'next/og';
import { readFile } from 'node:fs/promises';
import path from 'node:path';

export const dynamic = 'force-static';
export const alt = 'Hasibul Hussain — I build my own products.';
export const size = { width: 1200, height: 630 };
export const contentType = 'image/png';

export default async function SocialImage() {
  const portrait = await readFile(path.join(process.cwd(), 'public/assets/img/hasibul-hussain-portrait.jpeg'));
  return new ImageResponse(<div style={{ display: 'flex', width: '100%', height: '100%', background: '#09090b', color: '#fafafa', padding: '70px', alignItems: 'center', justifyContent: 'space-between', fontFamily: 'sans-serif' }}><div style={{ display: 'flex', flexDirection: 'column', maxWidth: 700 }}><div style={{ display: 'flex', fontSize: 26, color: '#a1a1aa', marginBottom: 26 }}>Hey, I&apos;m Hasibul Hussain</div><div style={{ display: 'flex', flexDirection: 'column', fontSize: 76, fontWeight: 700, letterSpacing: '-4px', lineHeight: 1.1 }}><span>I build my</span><span style={{ color: '#f2ad86' }}>own products.</span></div><div style={{ display: 'flex', fontSize: 23, color: '#a1a1aa', marginTop: 32 }}>Developer &amp; founder · India</div><div style={{ display: 'flex', fontSize: 20, color: '#71717a', marginTop: 34 }}>hasibulhussain.online</div></div><img src={`data:image/jpeg;base64,${portrait.toString('base64')}`} alt="" width={280} height={350} style={{ borderRadius: 24, objectFit: 'cover' }} /></div>, size);
}
