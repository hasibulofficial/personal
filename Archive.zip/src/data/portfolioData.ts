import type { BrandIconKey } from '../components/BrandIcons';

export const PORTRAIT_IMAGE_PATH =
  '/assets/img/hasibul-hussain-portrait.jpeg';

export const BANNER_IMAGE_PATH =
  '/assets/img/night-drive-banner.png';

export interface JourneyEntry {
  id: string;
  period: string;
  title: string;
  role: string;
  summary: string;
  highlights: string[];
  tags: string[];
}

export const JOURNEY_ENTRIES: JourneyEntry[] = [
  {
    id: 'upcoming-2026',
    period: '2026 — Present',
    title: 'My next product',
    role: 'Building independently',
    summary:
      "I'm building my next software product, bringing together full-stack development, product thinking, and AI. I'm still working through the details, and I'll share more when it's ready.",
    highlights: [
      "I'm exploring where AI agents can solve everyday problems",
      "I'm building, testing, and learning as I go",
    ],
    tags: ['Next.js', 'TypeScript', 'AI Agents', 'LLMs'],
  },
  {
    id: 'hostgenics',
    period: '2022 — 2024',
    title: 'Hostgenics',
    role: 'Founder',
    summary:
      'I started Hostgenics in 2022, built and ran the hosting business, and grew it to over 10,000 active customers. I handled the servers, marketing, and day-to-day operations before selling the company in 2024.',
    highlights: [
      'I founded it in 2022 and sold it in 2024',
      'I grew it to serve over 10,000 active customers',
      'I managed WHM, Linux servers, and the hosting infrastructure',
      'I grew the business with Google Ads and Meta Ads',
    ],
    tags: ['WHM', 'Linux Servers', 'Google Ads', 'Meta Ads'],
  },
];

export const EDUCATION_ENTRY = {
  institution: 'Grameen Jyoti Academy',
  credential: 'Completed Class 10',
  period: '2026',
  note: 'I completed Class 10 in 2026. Alongside school, I learned by experimenting, running a business, and building things from scratch.',
};

export type SkillCategoryFilter =
  | 'all'
  | 'frontend'
  | 'backend'
  | 'marketing'
  | 'infrastructure'
  | 'ai';

export interface SkillChip {
  name: string;
  icon: BrandIconKey;
  accent: string;
  detail: string;
}

export interface SkillGroup {
  id: Exclude<SkillCategoryFilter, 'all'>;
  label: string;
  chips: SkillChip[];
}

export const SKILL_GROUPS: SkillGroup[] = [
  {
    id: 'frontend',
    label: 'Frontend & Languages',
    chips: [
      {
        name: 'TypeScript',
        icon: 'typescript',
        accent: '#3178C6',
        detail: "I use TypeScript to keep my products predictable as they grow.",
      },
      {
        name: 'React',
        icon: 'react',
        accent: '#61DAFB',
        detail: "I build reusable interfaces and interactions with React.",
      },
      {
        name: 'Next.js',
        icon: 'nextjs',
        accent: '#FAFAFA',
        detail: "I use Next.js to take my ideas from pages to complete products.",
      },
      {
        name: 'Three.js',
        icon: 'threejs',
        accent: '#D4A359',
        detail: "I experiment with 3D scenes, WebGL, and spatial interactions.",
      },
      {
        name: 'Tailwind',
        icon: 'tailwind',
        accent: '#38BDF8',
        detail: "I use Tailwind to move quickly without giving up the details.",
      },
      {
        name: 'JavaScript',
        icon: 'javascript',
        accent: '#F7DF1E',
        detail: "I use JavaScript for the browser logic behind my products.",
      },
      {
        name: 'HTML',
        icon: 'html',
        accent: '#E34F26',
        detail: "I write semantic HTML so my interfaces make sense to people and browsers.",
      },
      {
        name: 'CSS',
        icon: 'css',
        accent: '#33A9DC',
        detail: "I use CSS for layouts, typography, and the small details that make an interface feel right.",
      },
    ],
  },
  {
    id: 'backend',
    label: 'Backend, Systems & DB',
    chips: [
      {
        name: 'Node.js',
        icon: 'nodejs',
        accent: '#5FA04E',
        detail: "I build APIs and backend services with Node.js.",
      },
      {
        name: 'Python',
        icon: 'python',
        accent: '#3776AB',
        detail: "I use Python for automation, scripts, and AI experiments.",
      },
      {
        name: 'C++',
        icon: 'cpp',
        accent: '#659AD2',
        detail: "I learn systems programming, algorithms, and performance with C++.",
      },
      {
        name: 'PHP',
        icon: 'php',
        accent: '#777BB4',
        detail: "I work with PHP in web applications and the hosting ecosystem.",
      },
      {
        name: 'SQL',
        icon: 'sql',
        accent: '#38BDF8',
        detail: "I use SQL to model, store, and query my product data.",
      },
    ],
  },
  {
    id: 'marketing',
    label: 'Growth & Paid Ads',
    chips: [
      {
        name: 'Google Ads',
        icon: 'googleads',
        accent: '#4285F4',
        detail: "I use Google Ads to test acquisition and grow my products.",
      },
      {
        name: 'Meta Ads',
        icon: 'metaads',
        accent: '#0668E1',
        detail: "I use Meta Ads to experiment with audiences and creative ideas.",
      },
      {
        name: 'Campaign Analytics',
        icon: 'analytics',
        accent: '#F9AB00',
        detail: "I track what brings people to my products and what makes them stay.",
      },
    ],
  },
  {
    id: 'infrastructure',
    label: 'Servers, Hosting & DevOps',
    chips: [
      {
        name: 'WHM',
        icon: 'whm',
        accent: '#FF6C2C',
        detail: "I used WHM to manage accounts and production hosting at Hostgenics.",
      },
      {
        name: 'cPanel',
        icon: 'cpanel',
        accent: '#FF6C2C',
        detail: "I manage hosting accounts, domains, and deployments with cPanel.",
      },
      {
        name: 'Linux Servers',
        icon: 'linux',
        accent: '#F59E0B',
        detail: "I manage production servers and troubleshoot the infrastructure behind my products.",
      },
      {
        name: 'DNS & SSL',
        icon: 'dns',
        accent: '#34D399',
        detail: "I configure domains, routing, and certificates for the things I launch.",
      },
    ],
  },
  {
    id: 'ai',
    label: 'AI & Intelligent Systems',
    chips: [
      {
        name: 'LLMs',
        icon: 'llm',
        accent: '#10B981',
        detail: "I explore language models, prompting, and useful AI workflows.",
      },
      {
        name: 'AI Agents',
        icon: 'agents',
        accent: '#D4A359',
        detail: "I experiment with agents that can use tools and handle multi-step tasks.",
      },
      {
        name: 'AI APIs',
        icon: 'api',
        accent: '#A78BFA',
        detail: "I connect AI models to real features in my products.",
      },
      {
        name: 'Automation',
        icon: 'automation',
        accent: '#FBBF24',
        detail: "I automate repetitive work so I can spend more time building.",
      },
    ],
  },
];

export const INTERESTS = [
  'Night drives',
  'Discovering startup ideas',
  'Building websites',
  'Exploring new places',
  'Creating things from scratch',
  'Experimenting with emerging tech',
];

export interface SocialChannel {
  id: 'instagram' | 'x' | 'linkedin' | 'email';
  name: string;
  handle: string;
  href: string;
}

export const SOCIAL_CHANNELS: SocialChannel[] = [
  {
    id: 'instagram',
    name: 'Instagram',
    handle: '@heyhasibul',
    href: 'https://www.instagram.com/heyhasibul/',
  },
  {
    id: 'x',
    name: 'X',
    handle: '@hasibul_2813',
    href: 'https://x.com/hasibul_2813',
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    handle: 'in/hasibul-hussain',
    href: 'https://www.linkedin.com/in/hasibul-hussain',
  },
  {
    id: 'email',
    name: 'Email',
    handle: 'hasibulhussain2008@gmail.com',
    href: 'mailto:hasibulhussain2008@gmail.com',
  },
];
