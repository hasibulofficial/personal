export const SITE_URL = 'https://hasibulhussain.online';
export const SITE_TITLE = 'Hasibul Hussain | I Build My Own Products';
export const SITE_DESCRIPTION = "I'm Hasibul Hussain, a developer and founder from India. I build and grow my own software products. Previously, I built and sold Hostgenics.";
export const ABOUT_TEXT = "I'm Hasibul, a developer and founder from India. I build my own software products, from the first idea to the code, launch, and everything that comes after. I started Hostgenics in 2022, grew it to over 10,000 active customers, and sold it in 2024. These days, I'm working on my next product and exploring how AI agents can make useful software better.";
