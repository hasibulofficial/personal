import App from '../App';
import { SITE_DESCRIPTION, SITE_URL } from '../data/siteData';
import { SOCIAL_CHANNELS } from '../data/portfolioData';

export default function HomePage() {
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'ProfilePage',
    '@id': `${SITE_URL}/#profile`,
    url: `${SITE_URL}/`,
    name: 'Hasibul Hussain',
    description: SITE_DESCRIPTION,
    mainEntity: {
      '@type': 'Person',
      '@id': `${SITE_URL}/#person`,
      name: 'Hasibul Hussain',
      url: `${SITE_URL}/`,
      image: `${SITE_URL}/assets/img/hasibul-hussain-portrait.jpeg`,
      jobTitle: 'Developer and product founder',
      description: SITE_DESCRIPTION,
      knowsAbout: ['Software products', 'React', 'Next.js', 'TypeScript', 'AI agents', 'Web hosting'],
      sameAs: SOCIAL_CHANNELS.filter((channel) => channel.href.startsWith('https://')).map((channel) => channel.href),
    },
  };
  return <><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData).replace(/</g, '\\u003c') }} /><App /></>;
}
