export { default as GET } from '../../lib/socialImage';
export const dynamic = 'force-static';
