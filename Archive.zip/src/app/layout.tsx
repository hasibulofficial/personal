import type { Metadata, Viewport } from 'next';
import { SITE_DESCRIPTION, SITE_TITLE, SITE_URL } from '../data/siteData';
import '../index.css';

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: SITE_TITLE,
  description: SITE_DESCRIPTION,
  applicationName: 'Hasibul Hussain',
  authors: [{ name: 'Hasibul Hussain', url: SITE_URL }],
  creator: 'Hasibul Hussain',
  alternates: { canonical: '/' },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1, 'max-video-preview': -1 } },
  openGraph: { type: 'website', locale: 'en_IN', url: '/', title: SITE_TITLE, description: SITE_DESCRIPTION, siteName: 'Hasibul Hussain', images: [{ url: '/opengraph-image.png', width: 1200, height: 630, alt: 'Hasibul Hussain — I build my own products.' }] },
  twitter: { card: 'summary_large_image', creator: '@hasibul_2813', title: SITE_TITLE, description: SITE_DESCRIPTION, images: ['/opengraph-image.png'] },
  icons: { icon: '/assets/img/hasibul-hussain-portrait.jpeg', apple: '/assets/img/hasibul-hussain-portrait.jpeg' },
};

export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#09090b', colorScheme: 'dark light' };

const themeScript = `(function(){try{var t=localStorage.getItem('hasibul-theme');if(t!=='light'&&t!=='dark')t=matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light';document.documentElement.classList.remove('light','dark');document.documentElement.classList.add(t);document.documentElement.dataset.theme=t;}catch(e){}})();`;

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" className="dark" suppressHydrationWarning><head><script dangerouslySetInnerHTML={{ __html: themeScript }} /><link rel="preload" href="/fonts/manrope.woff2" as="font" type="font/woff2" crossOrigin="anonymous" /><noscript><style>{`.ambient-field,.reading-progress{display:none!important}main [style]{opacity:1!important;transform:none!important}html{scroll-behavior:auto!important}`}</style></noscript></head><body>{children}</body></html>;
}
