'use client';

import { MotionConfig } from 'motion/react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { JourneySection } from './components/JourneySection';
import { CapabilitiesSection } from './components/CapabilitiesSection';
import { BeyondSection } from './components/BeyondSection';
import { ContactSection } from './components/ContactSection';
import { VisitorSection } from './components/VisitorSection';
import { Footer } from './components/Footer';
import { SectionDivider } from './components/SectionDivider';
import { ScrollToTop } from './components/ScrollToTop';
import { ThemeProvider } from './components/ThemeProvider';
import { TooltipProvider } from './components/ui/tooltip';
import { BackgroundAmbience } from './components/BackgroundAmbience';

export default function App() {
  return (
    <ThemeProvider>
      <MotionConfig reducedMotion="user">
        <TooltipProvider delayDuration={250}>
          <div className="site-root">
            <a className="skip-link" href="#main-content">Skip to main content</a>
            <BackgroundAmbience />
            <Navbar />
            <main id="main-content" className="portfolio-shell">
              <HeroSection />
              <div className="portfolio-content">
                <JourneySection />
                <SectionDivider />
                <CapabilitiesSection />
                <SectionDivider />
                <BeyondSection />
                <SectionDivider />
                <ContactSection />
                <VisitorSection />
              </div>
            </main>
            <Footer />
            <ScrollToTop />
          </div>
        </TooltipProvider>
      </MotionConfig>
    </ThemeProvider>
  );
}
