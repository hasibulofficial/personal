import { useEffect, useState } from 'react';
import { Quote, Users } from 'lucide-react';

interface VisitorCount { total: number; visitorNumber: number | null; }
const VISITOR_KEY = 'hasibul-portfolio-visitor-id';
let visitRequest: Promise<VisitorCount> | undefined;

function validateCount(result: VisitorCount) {
  if (!Number.isSafeInteger(result.total) || result.total < 0 || (result.visitorNumber !== null && (!Number.isSafeInteger(result.visitorNumber) || result.visitorNumber < 1 || result.visitorNumber > result.total))) throw new Error('Invalid visitor count');
  return result;
}

function recordVisit(): Promise<VisitorCount> {
  if (visitRequest) return visitRequest;
  visitRequest = (async () => {
    let visitorId: string;
    try { visitorId = localStorage.getItem(VISITOR_KEY) || crypto.randomUUID(); localStorage.setItem(VISITOR_KEY, visitorId); }
    catch { visitorId = crypto.randomUUID(); }
    const response = await fetch('/api/visitors', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ visitorId }), cache: 'no-store', signal: AbortSignal.timeout(10_000) });
    if (!response.ok) throw new Error('Visitor count is unavailable');
    return validateCount(await response.json() as VisitorCount);
  })();
  void visitRequest.catch(() => { visitRequest = undefined; });
  return visitRequest;
}

export function ordinalSuffix(value: number): string {
  const lastTwo = value % 100;
  if (lastTwo >= 11 && lastTwo <= 13) return 'th';
  return ({ 1: 'st', 2: 'nd', 3: 'rd' } as Record<number, string>)[value % 10] || 'th';
}

export function VisitorSection() {
  const [visit, setVisit] = useState<VisitorCount | null>(null);
  useEffect(() => {
    let active = true;
    void recordVisit().then((result) => { if (active) setVisit(result); }).catch(() => {});
    const refresh = async () => {
      if (document.visibilityState !== 'visible') return;
      try {
        const response = await fetch('/api/visitors', { cache: 'no-store', credentials: 'same-origin', signal: AbortSignal.timeout(8_000) });
        if (!response.ok) return;
        const result = validateCount(await response.json() as VisitorCount);
        if (active) setVisit((current) => current ? { ...current, total: Math.max(current.total, result.total) } : result);
      } catch { /* Keep the last verified total during a temporary outage. */ }
    };
    const interval = window.setInterval(refresh, 30_000);
    document.addEventListener('visibilitychange', refresh);
    window.addEventListener('focus', refresh);
    return () => { active = false; window.clearInterval(interval); document.removeEventListener('visibilitychange', refresh); window.removeEventListener('focus', refresh); };
  }, []);
  return (
    <section className="visitor-section" aria-label="A reminder I live by and my all-time visitors">
      <div className="visitor-card">
        <figure className="visitor-quote"><Quote className="visitor-quote-mark" aria-hidden="true" /><div><blockquote><p>Keep showing up. Let the work speak for itself.</p></blockquote><figcaption>A reminder to myself</figcaption></div></figure>
        <div className="visitor-count" role="status" aria-live="polite" aria-atomic="true">
          <span className="visitor-count-label"><Users className="size-3.5" aria-hidden="true" />All-time visitors</span>
          {visit ? <><p className="visitor-total"><strong>{visit.total.toLocaleString('en-US')}</strong><span>and counting</span></p><p className="visitor-personal">{visit.visitorNumber ? `You're my ${visit.visitorNumber.toLocaleString('en-US')}${ordinalSuffix(visit.visitorNumber)} visitor. Thank you.` : 'Thanks for spending a little time here.'}</p></> : <p className="visitor-personal">Thanks for spending a little time here.</p>}
        </div>
      </div>
    </section>
  );
}
