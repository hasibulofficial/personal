import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowUp } from 'lucide-react';
import { prefersReducedMotion } from '../utils/motion';

export function ScrollToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const checkScroll = () => {
      const heroEl = document.getElementById('top');
      if (heroEl) {
        const rect = heroEl.getBoundingClientRect();
        setVisible(rect.bottom <= 72);
      } else {
        setVisible(window.scrollY > 520);
      }
    };

    checkScroll();
    window.addEventListener('scroll', checkScroll, { passive: true });
    window.addEventListener('resize', checkScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', checkScroll);
      window.removeEventListener('resize', checkScroll);
    };
  }, []);

  const handleClick = () => {
    window.scrollTo({
      top: 0,
      behavior: prefersReducedMotion() ? 'auto' : 'smooth',
    });
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.button
          type="button"
          onClick={handleClick}
          aria-label="Scroll to top"
          initial={{ opacity: 0, y: 12, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 12, scale: 0.9 }}
          transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="fixed bottom-5 right-5 sm:bottom-6 sm:right-6 z-40 w-11 h-11 rounded-lg bg-muted/95 backdrop-blur-md border border-white/[0.14] hover:border-white/35 hover:bg-accent text-foreground shadow-lg shadow-black/40 flex items-center justify-center transition-colors cursor-pointer active:scale-95"
        >
          <ArrowUp className="w-4 h-4" strokeWidth={1.75} />
        </motion.button>
      )}
    </AnimatePresence>
  );
}
