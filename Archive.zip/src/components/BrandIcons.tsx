import {
  siCpanel,
  siCplusplus,
  siCloudflare,
  siCss,
  siDigitalocean,
  siGoogleads,
  siGooglegemini,
  siGoogleanalytics,
  siHtml5,
  siInstagram,
  siJavascript,
  siLangchain,
  siLinux,
  siMeta,
  siModelcontextprotocol,
  siN8n,
  siNextdotjs,
  siNodedotjs,
  siPhp,
  siPostgresql,
  siPython,
  siReact,
  siTailwindcss,
  siThreedotjs,
  siTypescript,
  siX,
  type SimpleIcon,
} from 'simple-icons';
import { Mail } from 'lucide-react';

export type BrandIconKey =
  | 'react'
  | 'nextjs'
  | 'typescript'
  | 'threejs'
  | 'javascript'
  | 'html'
  | 'css'
  | 'tailwind'
  | 'nodejs'
  | 'python'
  | 'cpp'
  | 'php'
  | 'sql'
  | 'googleads'
  | 'metaads'
  | 'analytics'
  | 'whm'
  | 'cpanel'
  | 'linux'
  | 'dns'
  | 'llm'
  | 'agents'
  | 'api'
  | 'automation';

const ICON_MAP: Record<BrandIconKey, { icon: SimpleIcon; darkInvert?: boolean }> = {
  react: { icon: siReact },
  nextjs: { icon: siNextdotjs, darkInvert: true },
  typescript: { icon: siTypescript },
  threejs: { icon: siThreedotjs, darkInvert: true },
  tailwind: { icon: siTailwindcss },
  javascript: { icon: siJavascript },
  html: { icon: siHtml5 },
  css: { icon: siCss },
  nodejs: { icon: siNodedotjs },
  python: { icon: siPython },
  cpp: { icon: siCplusplus },
  php: { icon: siPhp },
  sql: { icon: siPostgresql },
  googleads: { icon: siGoogleads },
  metaads: { icon: siMeta },
  analytics: { icon: siGoogleanalytics },
  whm: { icon: siDigitalocean },
  cpanel: { icon: siCpanel },
  linux: { icon: siLinux, darkInvert: true },
  dns: { icon: siCloudflare },
  llm: { icon: siGooglegemini },
  agents: { icon: siLangchain, darkInvert: true },
  api: { icon: siModelcontextprotocol, darkInvert: true },
  automation: { icon: siN8n },
};

export function BrandSkillIcon({
  icon,
  className = 'w-4 h-4 shrink-0',
}: {
  icon: BrandIconKey;
  className?: string;
}) {
  const entry = ICON_MAP[icon];
  const color = entry.darkInvert ? 'currentColor' : `#${entry.icon.hex}`;

  return (
    <svg
      viewBox="0 0 24 24"
      fill={color}
      className={className}
      aria-hidden="true"
    >
      <path d={entry.icon.path} />
    </svg>
  );
}

export function SocialBrandIcon({
  id,
  className = 'w-4 h-4 shrink-0',
}: {
  id: 'instagram' | 'x' | 'linkedin' | 'email';
  className?: string;
}) {
  if (id === 'instagram') {
    return (
      <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
        <path d={siInstagram.path} />
      </svg>
    );
  }
  if (id === 'x') {
    return (
      <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
        <path d={siX.path} />
      </svg>
    );
  }
  if (id === 'linkedin') {
    return (
      <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
      </svg>
    );
  }
  return <Mail className={className} strokeWidth={1.75} />;
}
