import { motion, useReducedMotion } from 'motion/react';
import { IcyFleurSticker } from 'stick-it-up';
import { SOCIAL_CHANNELS } from '../data/portfolioData';
import { SocialBrandIcon } from './BrandIcons';

export function Footer() {
  const reducedMotion = useReducedMotion();

  return (
    <footer className="py-12 sm:py-14 px-4 sm:px-6 text-center bg-card">
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.25 }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      >
        <div className="mb-3 flex justify-center">
          <IcyFleurSticker size={36} peel />
        </div>
        <div className="footer-signature">
          <p>Hasibul Hussain</p>
          <motion.span
            aria-hidden="true"
            className="footer-signature-stroke"
            initial={reducedMotion ? false : { scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
          />
        </div>
        <p className="mt-2 text-sm text-muted-foreground">
          Thanks for visiting my little corner of the internet.
        </p>

        <div className="mt-6 flex flex-col items-center gap-2.5">
          <span className="text-xs text-muted-foreground">Follow me</span>
          <div className="flex items-center justify-center gap-2">
            {SOCIAL_CHANNELS.map((channel, idx) => {
              const isExternal = channel.href.startsWith('http');
              return (
                <motion.a
                  key={channel.id}
                  href={channel.href}
                  target={isExternal ? '_blank' : undefined}
                  rel={isExternal ? 'noopener noreferrer' : undefined}
                  aria-label={`${channel.name} (${channel.handle})`}
                  initial={{ opacity: 0, y: 8 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.25 }}
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.96 }}
                  transition={{
                    duration: 0.28,
                    delay: 0.08 + idx * 0.04,
                    ease: [0.22, 1, 0.36, 1],
                  }}
                  className="w-11 h-11 rounded-md bg-muted border border-border hover:border-foreground/25 text-muted-foreground hover:text-foreground flex items-center justify-center transition-colors"
                >
                  <SocialBrandIcon id={channel.id} className="w-4 h-4" />
                </motion.a>
              );
            })}
          </div>
        </div>

        <p className="mt-8 text-xs text-muted-foreground">
          © {new Date().getFullYear()} Hasibul Hussain · India
        </p>
      </motion.div>
    </footer>
  );
}
