import { motion } from 'motion/react';
import { CarFront, Code2, Compass, Lightbulb, Shapes, Sparkles } from 'lucide-react';
import {
  CuriousGlobeSticker,
  KuroLaptopSticker,
  KuroRocketSticker,
} from 'stick-it-up';
import { INTERESTS } from '../data/portfolioData';

const INTEREST_ICONS = [CarFront, Lightbulb, Code2, Compass, Shapes, Sparkles];

export function BeyondSection() {
  return (
    <section id="beyond" tabIndex={-1} className="scroll-mt-28">
      <div className="section-heading flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
        >
          <span className="section-eyebrow">The rest of me</span>
          <h2 className="text-foreground">
            Away from the keyboard.
          </h2>
          <p className="mt-1.5 text-base leading-relaxed text-muted-foreground">
            When I&apos;m not building, I&apos;m usually chasing a new idea, a new place, or a good night drive.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 6 }}
          whileInView={{ opacity: 1, scale: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.35, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
          className="flex items-center gap-2 shrink-0"
        >
          <CuriousGlobeSticker size={40} peel className="-rotate-6" />
          <KuroLaptopSticker size={40} peel className="rotate-3" />
          <KuroRocketSticker size={40} peel className="-rotate-3" />
        </motion.div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
        {INTERESTS.map((interest, idx) => {
          const Icon = INTEREST_ICONS[idx];
          const isLastMobile = idx === INTERESTS.length - 1;
          const isBottomRowSm = idx >= INTERESTS.length - 2;
          const isBottomRowMd = idx >= INTERESTS.length - 3;
          const hasRightSm = idx % 2 === 0;
          const hasRightMd = idx % 3 !== 2;

          return (
            <motion.div
              key={interest}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{
                duration: 0.32,
                delay: idx * 0.045,
                ease: [0.22, 1, 0.36, 1],
              }}
              className={`px-4 sm:px-5 py-4 hover:bg-foreground/[0.025] transition-colors group flex items-center gap-2.5 text-sm text-muted-foreground hover:text-foreground border-border ${
                isLastMobile ? 'border-b-0' : 'border-b'
              } ${isBottomRowSm ? 'sm:border-b-0' : 'sm:border-b'} ${
                isBottomRowMd ? 'md:border-b-0' : 'md:border-b'
              } ${hasRightSm ? 'sm:border-r' : 'sm:border-r-0'} ${
                hasRightMd ? 'md:border-r' : 'md:border-r-0'
              }`}
            >
              <Icon aria-hidden="true" strokeWidth={1.65} className="size-4 shrink-0 text-muted-foreground transition-colors group-hover:text-foreground" />
              <span>{interest}</span>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
