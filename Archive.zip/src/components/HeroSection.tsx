import { motion, useReducedMotion } from 'motion/react';
import { Boxes, Code2, Hand, MapPin, Sparkles } from 'lucide-react';
import { BANNER_IMAGE_PATH, SOCIAL_CHANNELS } from '../data/portfolioData';
import { ABOUT_TEXT } from '../data/siteData';
import { SocialBrandIcon } from './BrandIcons';
import { PortraitTilt } from './PortraitTilt';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from './ui/tooltip';

export function HeroSection() {
  const reducedMotion = useReducedMotion();
  return (
    <>
      <section id="top" tabIndex={-1} className="hero-section" aria-labelledby="hero-title">
        <div className="hero-copy">
          <motion.p initial={false} animate={{ y: 0 }} className="hero-greeting">
            <Hand className="size-[18px]" aria-hidden="true" />
            Hey, I&apos;m Hasibul Hussain
          </motion.p>
          <motion.h1 id="hero-title" initial={reducedMotion ? false : { y: 14 }} animate={{ y: 0 }} transition={{ duration: .7, ease: [.22, 1, .36, 1] }} className="hero-headline">
            I build my<br /><em>own products.</em>
          </motion.h1>
          <p className="hero-description">
            I&apos;m a developer and founder from India. I turn the ideas I can&apos;t stop thinking about into software people can actually use.
          </p>
          <div className="hero-actions">
            <Button asChild size="lg" className="hero-primary-button">
              <a href="#experience"><Boxes className="size-4" aria-hidden="true" />What I&apos;m building</a>
            </Button>
            <Button asChild variant="outline" size="lg" className="hero-secondary-button">
              <a href="#contact">Say hello</a>
            </Button>
          </div>
          <div className="hero-context">
            <span><MapPin className="size-3.5" aria-hidden="true" />Based in India</span>
            <span className="hero-context-divider" aria-hidden="true" />
            <span>Building independently</span>
          </div>
        </div>

        <motion.div className="hero-visual" initial={reducedMotion ? false : { y: 25, rotate: 2 }} animate={{ y: 0, rotate: 0 }} transition={{ duration: .9, ease: [.22, 1, .36, 1] }}>
          <div className="hero-visual-backplate" aria-hidden="true">
            <img src={BANNER_IMAGE_PATH} alt="" width={1536} height={1024} />
          </div>
          <div className="hero-photo-card">
            <PortraitTilt introReady shape="card" className="hero-portrait-frame" />
            <div className="hero-photo-caption">
              <span>Hasibul Hussain</span>
              <span>Developer &amp; founder</span>
            </div>
          </div>
          <motion.div className="hero-floating-note" animate={reducedMotion ? undefined : { y: [0, -7, 0] }} transition={{ duration: 4.8, ease: 'easeInOut', repeat: Infinity }}>
            <span className="hero-note-icon"><Code2 className="size-5" aria-hidden="true" /></span>
            <div><span>From an idea</span><strong>to something real.</strong></div>
          </motion.div>
          <Badge variant="outline" className="hero-visual-badge"><Sparkles className="size-3.5" aria-hidden="true" />Always learning. Always building.</Badge>
          <span className="hero-visual-cross" aria-hidden="true">+</span>
        </motion.div>
      </section>

      <motion.section id="about" tabIndex={-1} aria-labelledby="about-title" initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .15 }} transition={{ duration: .55 }} className="about-section scroll-mt-28">
        <div className="about-label"><span className="section-eyebrow">A little context</span><h2 id="about-title">A bit about me.</h2></div>
        <div className="about-copy">
          <p>{ABOUT_TEXT}</p>
          <div className="about-socials">
            {SOCIAL_CHANNELS.map((channel) => {
              const external = channel.href.startsWith('http');
              return <Tooltip key={channel.id}><TooltipTrigger asChild><Button asChild variant="outline" size="icon" className="size-11 rounded-full"><a href={channel.href} target={external ? '_blank' : undefined} rel={external ? 'noopener noreferrer' : undefined} aria-label={`${channel.name} (${channel.handle})`}><SocialBrandIcon id={channel.id} className="size-4" /></a></Button></TooltipTrigger><TooltipContent sideOffset={8}>{channel.name}</TooltipContent></Tooltip>;
            })}
          </div>
        </div>
      </motion.section>
    </>
  );
}
