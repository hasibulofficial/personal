import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { SKILL_GROUPS, type SkillCategoryFilter, type SkillChip } from '../data/portfolioData';
import { BrandSkillIcon } from './BrandIcons';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Tooltip, TooltipContent, TooltipTrigger } from './ui/tooltip';

const FILTER_TABS: { id: SkillCategoryFilter; label: string }[] = [
  { id: 'all', label: 'All' }, { id: 'frontend', label: 'Frontend' },
  { id: 'backend', label: 'Backend' }, { id: 'marketing', label: 'Growth' },
  { id: 'infrastructure', label: 'Servers' }, { id: 'ai', label: 'AI & Agents' },
];

export function CapabilitiesSection() {
  const [filter, setFilter] = useState<SkillCategoryFilter>('all');
  const [activeChip, setActiveChip] = useState<SkillChip | null>(null);
  const visibleGroups = filter === 'all' ? SKILL_GROUPS : SKILL_GROUPS.filter((group) => group.id === filter);
  return (
    <section id="skills" tabIndex={-1} className="scroll-mt-28" aria-labelledby="stack-title">
      <Tabs value={filter} onValueChange={(value) => { setFilter(value as SkillCategoryFilter); setActiveChip(null); }} className="gap-0">
        <div className="section-heading">
          <motion.div initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: .4 }}>
            <span className="section-eyebrow">My toolkit</span>
            <h2 id="stack-title">The tech behind my ideas.</h2>
            <p className="mt-3 text-base leading-relaxed text-muted-foreground">These are the tools I reach for to build, launch, and grow my own products.</p>
          </motion.div>
          <TabsList aria-label="Filter tech stack by category" className="stack-tabs mt-5 flex h-auto w-full flex-wrap justify-start gap-1.5 bg-transparent p-0">
            {FILTER_TABS.map((tab) => <TabsTrigger key={tab.id} value={tab.id} className="min-h-11 flex-none rounded-full border border-border bg-muted/50 px-4 py-2 text-sm data-[state=active]:border-foreground data-[state=active]:bg-foreground data-[state=active]:text-background dark:data-[state=active]:border-foreground dark:data-[state=active]:bg-foreground dark:data-[state=active]:text-background">{tab.label}</TabsTrigger>)}
          </TabsList>
        </div>
        <TabsContent value={filter} className="m-0">
          <motion.div key={filter} initial={{ opacity: 0, y: 7 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .25 }} className="stack-groups">
            {visibleGroups.map((group) => <div key={group.id} className="stack-group">
              <h3 className="mb-4 text-sm font-medium text-muted-foreground">{group.label}</h3>
              <div className="flex flex-wrap gap-2">
                {group.chips.map((chip) => {
                  const active = activeChip?.name === chip.name;
                  return <Tooltip key={chip.name}><TooltipTrigger asChild><Button asChild variant="outline" className={`min-h-11 rounded-lg border-border bg-card px-3 text-sm font-medium shadow-none hover:border-foreground/25 ${active ? 'border-foreground/25 bg-accent' : ''}`}><motion.button type="button" whileHover={{ y: -2 }} whileTap={{ scale: .96 }} aria-pressed={active} onFocus={() => setActiveChip(chip)} onMouseEnter={() => setActiveChip(chip)} onClick={() => setActiveChip(chip)}><BrandSkillIcon icon={chip.icon} className="size-4" /><span>{chip.name}</span></motion.button></Button></TooltipTrigger><TooltipContent sideOffset={8} className="max-w-64 text-sm leading-relaxed">{chip.detail}</TooltipContent></Tooltip>;
                })}
              </div>
            </div>)}
          </motion.div>
        </TabsContent>
      </Tabs>
      <div className="stack-detail" aria-live="polite">
        <AnimatePresence mode="wait"><motion.p key={activeChip?.name || 'hint'} initial={{ opacity: 0, y: 3 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -3 }} transition={{ duration: .15 }} className="text-sm leading-relaxed text-muted-foreground">{activeChip ? <><span className="font-semibold text-foreground">{activeChip.name}. </span>{activeChip.detail}</> : 'Pick a tool to see how I use it.'}</motion.p></AnimatePresence>
      </div>
    </section>
  );
}
