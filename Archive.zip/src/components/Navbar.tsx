import { useCallback, useEffect, useRef, useState, type MouseEvent } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { ChevronRight, Menu, X } from 'lucide-react';
import { CatSitSticker } from 'stick-it-up';
import { ThemeToggle } from './ThemeToggle';
import { Button } from './ui/button';

const LINKS = [
  { id: 'about', label: 'About' },
  { id: 'experience', label: 'My work' },
  { id: 'skills', label: 'Stack' },
  { id: 'beyond', label: 'Beyond Work' },
  { id: 'contact', label: 'Contact' },
];

const easing = [0.22, 1, 0.36, 1] as const;

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [activeId, setActiveId] = useState('');
  const header = useRef<HTMLElement>(null);
  const menuButton = useRef<HTMLButtonElement>(null);
  const scrollFrame = useRef(0);
  const reducedMotion = useReducedMotion();

  const cancelScroll = useCallback(() => {
    window.cancelAnimationFrame(scrollFrame.current);
    scrollFrame.current = 0;
  }, []);

  const scrollToSection = (section: HTMLElement) => {
    cancelScroll();
    const start = window.scrollY;
    const margin = Number.parseFloat(getComputedStyle(section).scrollMarginTop) || 0;
    const scrollLimit = (document.scrollingElement?.scrollHeight ?? 0) - window.innerHeight;
    const destination = Math.max(0, Math.min(scrollLimit, start + section.getBoundingClientRect().top - margin));
    const distance = destination - start;

    if (reducedMotion || Math.abs(distance) < 2) {
      window.scrollTo({ top: destination, behavior: 'instant' });
      return;
    }

    const duration = Math.min(650, 300 + Math.abs(distance) * .13);
    const startedAt = performance.now();
    const step = (time: number) => {
      const progress = Math.min(1, (time - startedAt) / duration);
      const eased = progress * progress * (3 - 2 * progress);
      window.scrollTo({ top: start + distance * eased, behavior: 'instant' });
      scrollFrame.current = progress < 1 ? window.requestAnimationFrame(step) : 0;
    };
    scrollFrame.current = window.requestAnimationFrame(step);
  };

  const navigateToSection = (event: MouseEvent<HTMLAnchorElement>) => {
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;

    const { hash } = event.currentTarget;
    const section = document.getElementById(hash.slice(1));
    if (!section) return;

    event.preventDefault();
    if (window.location.hash !== hash) {
      window.history.pushState(null, '', hash);
    }

    section.focus({ preventScroll: true });
    scrollToSection(section);
    setOpen(false);
  };

  useEffect(() => {
    window.addEventListener('wheel', cancelScroll, { passive: true });
    window.addEventListener('pointerdown', cancelScroll, { passive: true });
    window.addEventListener('popstate', cancelScroll);
    return () => {
      window.removeEventListener('wheel', cancelScroll);
      window.removeEventListener('pointerdown', cancelScroll);
      window.removeEventListener('popstate', cancelScroll);
      cancelScroll();
    };
  }, [cancelScroll]);

  useEffect(() => {
    const sections = LINKS.map(({ id }) => document.getElementById(id));
    let frame = 0;
    const updateActiveSection = () => {
      frame = 0;
      const marker = (header.current?.getBoundingClientRect().bottom ?? 0) + 16;
      let current = '';

      for (const section of sections) {
        if (section && section.getBoundingClientRect().top <= marker) current = section.id;
      }
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 40) {
        current = 'contact';
      }
      setActiveId(current);
    };
    const schedule = () => {
      if (!frame) frame = window.requestAnimationFrame(updateActiveSection);
    };

    updateActiveSection();
    window.addEventListener('scroll', schedule, { passive: true });
    window.addEventListener('resize', schedule, { passive: true });
    return () => {
      window.removeEventListener('scroll', schedule);
      window.removeEventListener('resize', schedule);
      window.cancelAnimationFrame(frame);
    };
  }, []);

  useEffect(() => {
    if (!open) return;

    const desktop = window.matchMedia('(min-width: 48rem)');
    const closeOnDesktop = () => {
      if (desktop.matches) setOpen(false);
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      setOpen(false);
      menuButton.current?.focus();
    };
    const closeOnOutsideTap = (event: PointerEvent) => {
      if (event.target instanceof Node && !header.current?.contains(event.target)) setOpen(false);
    };

    desktop.addEventListener('change', closeOnDesktop);
    window.addEventListener('keydown', closeOnEscape);
    window.addEventListener('pointerdown', closeOnOutsideTap);
    return () => {
      desktop.removeEventListener('change', closeOnDesktop);
      window.removeEventListener('keydown', closeOnEscape);
      window.removeEventListener('pointerdown', closeOnOutsideTap);
    };
  }, [open]);

  return (
    <header ref={header} className="site-navbar">
      <div className="site-navbar-inner">
        <a
          href="#top"
          className="site-navbar-brand"
          aria-label="Hasibul Hussain — Back to top"
          onClick={navigateToSection}
        >
          <CatSitSticker size={44} peel aria-hidden="true" focusable="false" />
        </a>

        <nav aria-label="Primary navigation" className="site-navbar-desktop">
          {LINKS.map(({ id, label }) => (
            <a
              key={id}
              href={`#${id}`}
              onClick={navigateToSection}
              aria-current={activeId === id ? 'location' : undefined}
              className={id === 'contact' ? 'site-navbar-contact' : 'site-navbar-link'}
            >
              {label}
            </a>
          ))}
        </nav>

        <div className="site-navbar-controls">
        <ThemeToggle />
        <Button
          ref={menuButton}
          type="button"
          onClick={() => setOpen((value) => !value)}
          aria-expanded={open}
          aria-controls="mobile-navigation"
          aria-label={open ? 'Close menu' : 'Open menu'}
          className="site-navbar-toggle"
          variant="outline"
          size="icon"
        >
          {open ? <X size={20} aria-hidden="true" /> : <Menu size={20} aria-hidden="true" />}
        </Button>
        </div>
      </div>

      <div id="mobile-navigation" inert={!open} className="site-navbar-dropdown">
        <AnimatePresence initial={false}>
          {open && (
            <motion.div
              initial={{ opacity: 0, height: 0, y: -5 }}
              animate={{ opacity: 1, height: 'auto', y: 0 }}
              exit={{ opacity: 0, height: 0, y: -5 }}
              transition={{ duration: reducedMotion ? 0 : .24, ease: easing }}
              className="site-navbar-dropdown-surface"
            >
              <nav aria-label="Mobile navigation" className="site-navbar-mobile">
                {LINKS.map(({ id, label }) => (
                  <a
                    key={id}
                    href={`#${id}`}
                    aria-current={activeId === id ? 'location' : undefined}
                    onClick={navigateToSection}
                    className={id === 'contact' ? 'site-navbar-contact site-navbar-mobile-contact' : 'site-navbar-mobile-link'}
                  >
                    {label}
                    <ChevronRight size={15} aria-hidden="true" />
                  </a>
                ))}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}
