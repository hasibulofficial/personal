import { useState, type PointerEvent } from 'react';
import { motion, useReducedMotion, useSpring } from 'motion/react';
import { PORTRAIT_IMAGE_PATH } from '../data/portfolioData';

export function PortraitTilt({
  introReady,
  shape = 'circle',
  className = 'w-20 h-20 sm:w-24 sm:h-24',
}: {
  introReady: boolean;
  shape?: 'circle' | 'card';
  className?: string;
}) {
  const [failed, setFailed] = useState(false);
  const reducedMotion = useReducedMotion();
  const rotateX = useSpring(0, { stiffness: 260, damping: 24 });
  const rotateY = useSpring(0, { stiffness: 260, damping: 24 });

  function tilt(event: PointerEvent<HTMLDivElement>) {
    if (reducedMotion || event.pointerType !== 'mouse') return;
    const bounds = event.currentTarget.getBoundingClientRect();
    rotateX.set((0.5 - (event.clientY - bounds.top) / bounds.height) * 12);
    rotateY.set(((event.clientX - bounds.left) / bounds.width - 0.5) * 12);
  }

  function resetTilt() {
    rotateX.set(0);
    rotateY.set(0);
  }

  return (
    <motion.div
      initial={reducedMotion ? false : 'waiting'}
      animate={introReady ? 'entered' : 'waiting'}
      variants={{
        waiting: { opacity: 0, scale: 0.91, rotate: -4, y: 12 },
        entered: { opacity: 1, scale: 1, rotate: 0, y: 0 },
      }}
      transition={{ duration: reducedMotion ? 0 : 0.58, delay: reducedMotion ? 0 : 0.04, ease: [0.22, 1, 0.36, 1] }}
      style={reducedMotion ? undefined : { transformPerspective: 480, rotateX, rotateY }}
      onPointerMove={tilt}
      onPointerLeave={resetTilt}
      onPointerCancel={resetTilt}
      data-intro-ready={introReady}
      className={`profile-portrait relative shrink-0 ${shape === 'card' ? 'rounded-3xl' : 'rounded-full'} ${className}`}
    >
      <div className={`relative size-full overflow-hidden ${shape === 'card' ? 'rounded-3xl' : 'rounded-full'} border-4 border-background ring-1 ring-foreground/10 bg-muted shadow-xl`}>
        {!failed ? (
          <img
            src={PORTRAIT_IMAGE_PATH}
            alt="Hasibul Hussain"
            loading="eager"
            decoding="async"
            fetchPriority="high"
            referrerPolicy="no-referrer"
            onError={() => setFailed(true)}
            className="w-full h-full object-cover object-top"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-muted text-sm font-semibold text-muted-foreground">
            HH
          </div>
        )}
      </div>
    </motion.div>
  );
}
