'use client';

import { motion, useReducedMotion, useScroll, useSpring } from 'motion/react';

export function BackgroundAmbience() {
  const reducedMotion = useReducedMotion();
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 28 });
  return (
    <>
      <div className="ambient-field" aria-hidden="true">
        <div className="ambient-glow ambient-glow-one" />
        <div className="ambient-glow ambient-glow-two" />
        <svg className="ambient-contours" viewBox="0 0 1440 1000" fill="none" preserveAspectRatio="xMidYMin slice">
          {[0, 1, 2, 3, 4].map((line) => <path key={line} d={`M-120 ${180 + line * 38} C 250 ${-180 + line * 46}, 720 ${680 + line * 28}, 1570 ${120 + line * 85}`} />)}
        </svg>
      </div>
      {!reducedMotion && <motion.div className="reading-progress" style={{ scaleX: progress }} aria-hidden="true" />}
    </>
  );
}
