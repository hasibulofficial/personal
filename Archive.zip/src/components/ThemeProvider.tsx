'use client';

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';

type Theme = 'light' | 'dark';
const ThemeContext = createContext<{ theme: Theme; toggleTheme: () => void }>({
  theme: 'dark', toggleTheme: () => {},
});

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>('dark');

  const applyTheme = useCallback((next: Theme, persist = false) => {
    document.documentElement.classList.toggle('dark', next === 'dark');
    document.documentElement.classList.toggle('light', next === 'light');
    document.documentElement.dataset.theme = next;
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', next === 'dark' ? '#09090b' : '#f5f6f8');
    if (persist) {
      try { localStorage.setItem('hasibul-theme', next); } catch { /* Theme still works without storage. */ }
    }
    setTheme(next);
  }, []);

  useEffect(() => {
    applyTheme(document.documentElement.classList.contains('light') ? 'light' : 'dark');
    const system = window.matchMedia('(prefers-color-scheme: dark)');
    const update = () => {
      try { if (localStorage.getItem('hasibul-theme')) return; } catch { /* Follow system theme. */ }
      applyTheme(system.matches ? 'dark' : 'light');
    };
    system.addEventListener('change', update);
    return () => system.removeEventListener('change', update);
  }, [applyTheme]);

  const toggleTheme = useCallback(() => applyTheme(theme === 'dark' ? 'light' : 'dark', true), [applyTheme, theme]);

  return <ThemeContext.Provider value={{ theme, toggleTheme }}>{children}</ThemeContext.Provider>;
}

export const useTheme = () => useContext(ThemeContext);
