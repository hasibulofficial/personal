import { motion } from 'motion/react';
import { Mail, MessageCircle } from 'lucide-react';
import { SOCIAL_CHANNELS } from '../data/portfolioData';
import { SocialBrandIcon } from './BrandIcons';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter, CardHeader } from './ui/card';

export function ContactSection() {
  return (
    <section id="contact" tabIndex={-1} className="contact-section scroll-mt-28" aria-labelledby="contact-title">
      <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .2 }} transition={{ duration: .5 }}>
        <Card className="contact-card">
          <CardHeader className="gap-4 p-6 sm:p-9">
            <Badge variant="outline" className="w-fit gap-1.5 px-3 py-1.5 font-normal"><MessageCircle className="size-3.5" aria-hidden="true" />Say hello</Badge>
            <h2 id="contact-title" className="contact-headline">Let&apos;s talk <em>products.</em></h2>
            <p className="max-w-xl text-base leading-relaxed text-muted-foreground">I spend my time building my own products and sharing what I learn. If you&apos;re building something too, I&apos;d love to hear about it.</p>
          </CardHeader>
          <CardContent className="px-6 pb-7 sm:px-9 sm:pb-9">
            <div className="flex flex-wrap gap-3">
              <Button asChild size="lg" className="min-h-11 rounded-lg"><a href="mailto:hasibulhussain2008@gmail.com"><Mail className="size-4" aria-hidden="true" />Email me</a></Button>
              <Button asChild variant="outline" size="lg" className="min-h-11 rounded-lg"><a href="https://x.com/hasibul_2813" target="_blank" rel="noopener noreferrer">Follow my journey</a></Button>
            </div>
          </CardContent>
          <CardFooter className="grid grid-cols-2 gap-0 border-t border-border p-0 sm:grid-cols-4">
            {SOCIAL_CHANNELS.map((channel, index) => {
              const external = channel.href.startsWith('http');
              return <Button key={channel.id} asChild variant="ghost" className={`h-auto min-h-14 justify-start gap-2.5 rounded-none px-5 py-4 text-sm text-muted-foreground ${index < 2 ? 'border-b border-border sm:border-b-0' : ''} ${index % 2 === 0 ? 'border-r border-border' : 'sm:border-r sm:last:border-r-0'}`}><a href={channel.href} target={external ? '_blank' : undefined} rel={external ? 'noopener noreferrer' : undefined} aria-label={`${channel.name} (${channel.handle})`}><SocialBrandIcon id={channel.id} className="size-4" />{channel.name}</a></Button>;
            })}
          </CardFooter>
        </Card>
      </motion.div>
    </section>
  );
}
