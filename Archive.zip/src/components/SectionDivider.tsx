import { motion, useReducedMotion } from 'motion/react';

export function SectionDivider() {
  const reducedMotion = useReducedMotion();

  return (
    <motion.div
      aria-hidden="true"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, amount: 0.35 }}
      transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      className="relative h-6 sm:h-7 w-full border-y border-border bg-hatch-pattern overflow-hidden"
    >
      {!reducedMotion && (
        <motion.span
          initial={{ x: '-100%', opacity: 0 }}
          whileInView={{ x: '100%', opacity: [0, 0.8, 0] }}
          viewport={{ once: true, amount: 0.35 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="pointer-events-none absolute inset-0 bg-linear-to-r from-transparent via-white/12 to-transparent"
        />
      )}
      <motion.span
        initial={{ opacity: 0, rotate: -45, scale: 0.7 }}
        whileInView={{ opacity: 1, rotate: 0, scale: 1 }}
        viewport={{ once: true, amount: 0.35 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="hidden sm:block absolute -left-[4.5px] -top-[4.5px] text-[10px] leading-none text-white/25 font-mono select-none"
      >
        +
      </motion.span>
      <motion.span
        initial={{ opacity: 0, rotate: 45, scale: 0.7 }}
        whileInView={{ opacity: 1, rotate: 0, scale: 1 }}
        viewport={{ once: true, amount: 0.35 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="hidden sm:block absolute -right-[4.5px] -top-[4.5px] text-[10px] leading-none text-white/25 font-mono select-none"
      >
        +
      </motion.span>
    </motion.div>
  );
}
