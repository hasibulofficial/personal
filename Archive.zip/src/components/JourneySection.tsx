import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, useInView, useReducedMotion, useScroll, useSpring } from 'motion/react';
import { Briefcase, ChevronDown, GraduationCap, Rocket } from 'lucide-react';
import { EDUCATION_ENTRY, JOURNEY_ENTRIES } from '../data/portfolioData';
import { prefersReducedMotion } from '../utils/motion';
import { Badge } from './ui/badge';

function AnimatedCustomerStat() {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.5 });
  const [value, setValue] = useState(10000);

  useEffect(() => {
    if (!inView) return;
    if (prefersReducedMotion()) {
      setValue(10000);
      return;
    }

    const duration = 1000;
    const start = performance.now();
    let rafId = 0;

    const frame = (now: number) => {
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(Math.round(eased * 10000));
      if (progress < 1) {
        rafId = requestAnimationFrame(frame);
      }
    };

    rafId = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(rafId);
  }, [inView]);

  return (
    <span ref={ref} className="font-mono-tabular text-foreground font-medium">
      {value.toLocaleString()}+
    </span>
  );
}

export function JourneySection() {
  const reducedMotion = useReducedMotion();
  const timeline = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: timeline,
    offset: ['start 65%', 'end 56%'],
    trackContentSize: true,
  });
  const progress = useSpring(scrollYProgress, { stiffness: 150, damping: 28, restDelta: 0.001 });
  const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>({
    'upcoming-2026': true,
    hostgenics: true,
  });

  const toggleEntry = (id: string) => {
    setExpandedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <section id="experience" tabIndex={-1} className="scroll-mt-28">
      <div className="section-heading">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
        >
          <span className="section-eyebrow">My work</span>
          <h2 className="text-foreground">
            My products, so far.
          </h2>
          <p className="mt-1.5 text-base leading-relaxed text-muted-foreground">
            From my first company to the next idea I&apos;m bringing to life.
          </p>
        </motion.div>
      </div>

      <div ref={timeline} className="journey-timeline">
        <div className="journey-track" aria-hidden="true">
          {!reducedMotion && <motion.div className="journey-track-fill" style={{ scaleY: progress }} />}
        </div>
        <div className="divide-y divide-border">
          {JOURNEY_ENTRIES.map((entry, idx) => {
            const isUpcoming = entry.id === 'upcoming-2026';
            const isOpen = !!expandedIds[entry.id];

            return (
              <motion.article
                key={entry.id}
                initial={reducedMotion ? false : { opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{
                  duration: 0.42,
                  delay: idx * 0.08,
                  ease: [0.22, 1, 0.36, 1],
                }}
                className="journey-stage group px-4 sm:px-6 py-6 hover:bg-foreground/[0.015] transition-colors"
              >
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.985 }}
                  onClick={() => toggleEntry(entry.id)}
                  aria-expanded={isOpen}
                  aria-controls={isOpen ? `details-${entry.id}` : undefined}
                  className="w-full text-left flex items-start gap-3.5 cursor-pointer"
                >
                  <span
                    aria-hidden="true"
                    className="journey-marker mt-0.5 w-8 h-8 rounded-lg bg-muted border border-border group-hover:border-foreground/25 flex items-center justify-center shrink-0 transition-colors"
                  >
                    {isUpcoming ? (
                      <Rocket className="w-4 h-4 text-foreground" strokeWidth={1.6} />
                    ) : (
                      <Briefcase className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" strokeWidth={1.6} />
                    )}
                  </span>

                  <div className="journey-stage-heading min-w-0 flex-1 flex items-start justify-between gap-x-3 gap-y-1">
                    <div>
                      <h3 className="text-lg font-semibold text-foreground">
                        {entry.title}
                      </h3>
                      <p className="text-xs text-muted-foreground">{entry.role}</p>
                    </div>
                    <div className="journey-stage-meta flex items-center gap-2 shrink-0 pt-0.5">
                      <span className="font-mono-tabular text-xs text-muted-foreground">
                        {entry.period}
                      </span>
                      <ChevronDown
                        strokeWidth={1.6}
                        className={`w-4 h-4 text-muted-foreground transition-transform duration-200 ${
                          isOpen ? 'rotate-180 text-foreground' : ''
                        }`}
                      />
                    </div>
                  </div>
                </motion.button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      id={`details-${entry.id}`}
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: reducedMotion ? 0 : 0.32, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden pl-[46px]"
                    >
                      <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                        {entry.id === 'hostgenics' ? (
                          <>
                            I started Hostgenics in 2022 and built it from the ground up.
                            I ran the servers, marketing, and day-to-day operations, grew it to{' '}
                            <AnimatedCustomerStat /> active customers before successfully selling the
                            company in 2024.
                          </>
                        ) : (
                          entry.summary
                        )}
                      </p>

                      <ul className="mt-3 space-y-1.5">
                        {entry.highlights.map((item) => (
                          <li
                            key={item}
                            className="text-sm text-muted-foreground flex items-start gap-2.5"
                          >
                            <span
                              aria-hidden="true"
                              className="mt-[7px] w-1 h-1 rounded-full bg-[#71717A] shrink-0"
                            />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>

                      <div className="mt-4 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-mono-tabular text-muted-foreground">
                        {entry.tags.map((tag) => <Badge key={tag} variant="outline" className="rounded-full px-2.5 py-1 font-normal text-muted-foreground">{tag}</Badge>)}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.article>
            );
          })}
        </div>

        {/* Education */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="journey-stage border-t border-border px-4 sm:px-6 py-6"
        >
          <h3 className="pl-[46px] text-lg font-semibold tracking-tight text-foreground">
            What I&apos;m learning
          </h3>

          <div className="mt-4 flex items-start justify-between gap-4">
            <div className="flex items-start gap-3.5 min-w-0">
              <span className="journey-marker w-8 h-8 rounded-lg bg-muted border border-border flex items-center justify-center shrink-0 mt-0.5">
                <GraduationCap className="w-4 h-4 text-muted-foreground" strokeWidth={1.6} />
              </span>
              <div className="min-w-0">
                <h4 className="text-base font-semibold text-foreground">
                  {EDUCATION_ENTRY.institution}
                </h4>
                <p className="text-sm text-muted-foreground mt-0.5">
                  {EDUCATION_ENTRY.credential}
                </p>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {EDUCATION_ENTRY.note}
                </p>
              </div>
            </div>
            <span className="font-mono-tabular text-xs text-muted-foreground shrink-0 pt-0.5">
              {EDUCATION_ENTRY.period}
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
