interface Statement {
  bind(...values: unknown[]): Statement;
}

export interface VisitorDatabase {
  prepare(sql: string): Statement;
  batch<T>(statements: Statement[]): Promise<{ results: T[] }[]>;
}

export interface Env {
  VISITORS_DB: VisitorDatabase;
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const COOKIE = 'portfolio_visitor';
const BOT = /bot\b|crawler|spider|slurp|headless|lighthouse|pagespeed|preview|facebookexternalhit/i;
const SCHEMA = `CREATE TABLE IF NOT EXISTS portfolio_visitors (
  number INTEGER PRIMARY KEY,
  visitor_hash TEXT NOT NULL UNIQUE
)`;

function json(data: unknown, status = 200, extraHeaders: Record<string, string> = {}) {
  return Response.json(data, {
    status,
    headers: {
      'Cache-Control': 'no-store, max-age=0',
      'X-Content-Type-Options': 'nosniff',
      ...extraHeaders,
    },
  });
}

export async function handleVisitors(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  if (url.pathname !== '/api/visitors') return json({ error: 'Not found' }, 404);

  if (request.method !== 'POST' && request.method !== 'GET') {
    return json({ error: 'Method not allowed' }, 405, { Allow: 'GET, POST' });
  }

  const origin = request.headers.get('Origin');
  if (origin && origin !== url.origin) return json({ error: 'Forbidden' }, 403);
  if (!env.VISITORS_DB) return json({ error: 'Visitor database is not configured' }, 503);

  let visitorId: string | undefined;
  const shouldCount = request.method === 'POST' && !BOT.test(request.headers.get('User-Agent') || '');

  if (shouldCount) {
    if (!request.headers.get('Content-Type')?.startsWith('application/json')) {
      return json({ error: 'Expected JSON' }, 415);
    }
    // Bound the body before parsing; the endpoint only needs a single UUID.
    const body = await request.text();
    if (body.length > 256) return json({ error: 'Request too large' }, 413);
    let suppliedId: unknown;
    try {
      suppliedId = JSON.parse(body)?.visitorId;
    } catch {
      return json({ error: 'Invalid JSON' }, 400);
    }
    if (typeof suppliedId !== 'string' || !UUID.test(suppliedId)) {
      return json({ error: 'Invalid visitor ID' }, 400);
    }

    const cookieId = request.headers.get('Cookie')?.split(';')
      .map((cookie) => cookie.trim())
      .find((cookie) => cookie.startsWith(`${COOKIE}=`))
      ?.slice(COOKIE.length + 1);
    visitorId = cookieId && UUID.test(cookieId) ? cookieId : suppliedId;
  }

  try {
    const db = env.VISITORS_DB;
    if (!visitorId) {
      const results = await db.batch<{ total: number }>([
        db.prepare(SCHEMA),
        db.prepare('SELECT COUNT(*) AS total FROM portfolio_visitors'),
      ]);
      return json({ total: results[1].results[0].total, visitorNumber: null });
    }

    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(visitorId));
    const hash = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');

    // D1 batches are transactions. UNIQUE makes refreshes, retries, and racing
    // tabs idempotent; SQLite assigns a number only to a genuinely new browser.
    const results = await db.batch<{ total: number; visitorNumber: number }>([
      db.prepare(SCHEMA),
      db.prepare('INSERT OR IGNORE INTO portfolio_visitors (visitor_hash) VALUES (?)').bind(hash),
      db.prepare(`SELECT COUNT(*) AS total,
        (SELECT number FROM portfolio_visitors WHERE visitor_hash = ?) AS visitorNumber
        FROM portfolio_visitors`).bind(hash),
    ]);
    const secure = url.protocol === 'https:' ? '; Secure' : '';
    return json(results[2].results[0], 200, {
      'Set-Cookie': `${COOKIE}=${visitorId}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax${secure}`,
    });
  } catch (error) {
    console.error('Visitor database request failed', error);
    return json({ error: 'Visitor count is temporarily unavailable' }, 503);
  }
}

export default { fetch: handleVisitors };
