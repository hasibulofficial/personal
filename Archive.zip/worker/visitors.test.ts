import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { test } from 'node:test';
import { handleVisitors, type VisitorDatabase } from './visitors';
import { ordinalSuffix } from '../src/components/VisitorSection';

function database(): VisitorDatabase {
  const sqlite = new DatabaseSync(':memory:');
  return {
    prepare(sql) {
      const statement = {
        sql,
        values: [] as unknown[],
        bind(...values: unknown[]) { statement.values = values; return statement; },
      };
      return statement;
    },
    async batch(statements) {
      sqlite.exec('BEGIN');
      try {
        const results = statements.map((item) => {
          const { sql, values } = item as unknown as { sql: string; values: [] };
          const statement = sqlite.prepare(sql);
          if (sql.trim().startsWith('SELECT')) return { results: statement.all(...values) };
          statement.run(...values);
          return { results: [] };
        });
        sqlite.exec('COMMIT');
        return results as never;
      } catch (error) {
        sqlite.exec('ROLLBACK');
        throw error;
      }
    },
  };
}

function visit(visitorId: string, headers: Record<string, string> = {}) {
  return new Request('https://hasibulhussain.online/api/visitors', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Origin: 'https://hasibulhussain.online',
      'User-Agent': 'Mozilla/5.0',
      ...headers,
    },
    body: JSON.stringify({ visitorId }),
  });
}

test('new browsers increment; refreshes and retries preserve the original number', async () => {
  const env = { VISITORS_DB: database() };
  const first = crypto.randomUUID();
  const second = crypto.randomUUID();
  assert.deepEqual(await (await handleVisitors(visit(first), env)).json(), { total: 1, visitorNumber: 1 });
  assert.deepEqual(await (await handleVisitors(visit(first), env)).json(), { total: 1, visitorNumber: 1 });
  assert.deepEqual(await (await handleVisitors(visit(second), env)).json(), { total: 2, visitorNumber: 2 });
  assert.deepEqual(await (await handleVisitors(visit(first), env)).json(), { total: 2, visitorNumber: 1 });
  assert.deepEqual(await (await handleVisitors(visit(crypto.randomUUID()), env)).json(), { total: 3, visitorNumber: 3 });
});

test('cookie prevents double counting when localStorage is reset or blocked', async () => {
  const env = { VISITORS_DB: database() };
  const response = await handleVisitors(visit(crypto.randomUUID()), env);
  const cookie = response.headers.get('Set-Cookie')!;
  assert.match(cookie, /HttpOnly; SameSite=Lax; Secure/);
  assert.equal(response.headers.get('Cache-Control'), 'no-store, max-age=0');
  const repeated = await handleVisitors(visit(crypto.randomUUID(), { Cookie: cookie.split(';')[0] }), env);
  assert.deepEqual(await repeated.json(), { total: 1, visitorNumber: 1 });
});

test('reads and common crawlers never increment the total', async () => {
  const env = { VISITORS_DB: database() };
  const read = () => handleVisitors(new Request('https://hasibulhussain.online/api/visitors'), env);
  assert.deepEqual(await (await read()).json(), { total: 0, visitorNumber: null });
  assert.deepEqual(await (await handleVisitors(visit(crypto.randomUUID(), { 'User-Agent': 'Googlebot' }), env)).json(), { total: 0, visitorNumber: null });
  assert.deepEqual(await (await read()).json(), { total: 0, visitorNumber: null });
});

test('invalid IDs, foreign origins, and unsupported methods cannot change the count', async () => {
  const env = { VISITORS_DB: database() };
  assert.equal((await handleVisitors(visit('invalid'), env)).status, 400);
  assert.equal((await handleVisitors(visit(crypto.randomUUID(), { Origin: 'https://example.com' }), env)).status, 403);
  assert.equal((await handleVisitors(new Request('https://hasibulhussain.online/api/visitors', { method: 'DELETE' }), env)).status, 405);
  assert.deepEqual(await (await handleVisitors(new Request('https://hasibulhussain.online/api/visitors'), env)).json(), { total: 0, visitorNumber: null });
});

test('ordinal suffixes cover the teens and larger totals', () => {
  for (const [value, suffix] of [[1, 'st'], [2, 'nd'], [3, 'rd'], [4, 'th'], [11, 'th'], [12, 'th'], [13, 'th'], [21, 'st'], [111, 'th'], [41326, 'th']] as const) {
    assert.equal(ordinalSuffix(value), suffix);
  }
});
