# Hasibul Hussain's portfolio

React, TypeScript, and Vite portfolio for https://hasibulhussain.online.

## Development

```sh
npm install
npm run dev
```

The quote and visitor card lives in `src/components/VisitorSection.tsx`.

## Real visitor counter

`worker/visitors.ts` is a separate Cloudflare Worker named
`hasibul-visitor-counter`, with the `VISITORS_DB` D1 binding connected to
`hasibul-portfolio-visitors`. Its route is
`hasibulhussain.online/api/visitors`. The portfolio itself remains on the existing
`wild-queen-cd3b` static Worker.

- Counts start at zero when the counter is installed. Past visits cannot be recovered.
- Each new browser gets a permanent visitor number stored in D1. Returning visitors
  see their original number, and refreshing does not increment the total.
- An anonymous UUID in localStorage and a first-party HttpOnly cookie identify the
  browser. Only its SHA-256 hash is stored in D1. No IP addresses are stored.
- Different browsers/devices or clearing both storage and cookies count as a new
  visitor. This measures browsers, not verified individual people.
- Common crawler user agents and read-only GET requests do not increment the count.
- `GET /api/visitors` returns the current total without recording a visit.
- `POST /api/visitors` accepts `{ "visitorId": "a UUID v4" }` and returns
  `{ "total": 1, "visitorNumber": 1 }`. A database uniqueness constraint and
  transaction prevent duplicate increments on retries.
- If the endpoint is unavailable, the card displays a thank-you message instead
  of a made-up number.

For local counter development, run `npx wrangler dev --port 8787` in another
terminal. Vite proxies `/api/visitors` to this local Worker, whose D1 data is
separate from production.

## Build and verification

```sh
npm run build
npx tsc --noEmit
node --import tsx --test worker/visitors.test.ts
```

The backend tests use Node's built-in SQLite support (Node 22.13+).
Upload the contents of `dist/`, or `hasibul-hussain-site-upload.zip`, as a new
deployment of `wild-queen-cd3b` in Cloudflare. The visitor database is separate
and survives portfolio uploads.

To update the counter, deploy `worker/visitors.ts` with Wrangler using the
included `wrangler.jsonc`, or generate a bundle with esbuild and paste it into
the counter Worker's dashboard editor. The generated bundle is not kept in the
project:

```sh
npx esbuild worker/visitors.ts --bundle --format=esm --target=es2022 --outfile=visitor-counter-worker.js
```

Preserve the existing database binding and route when updating the Worker.
